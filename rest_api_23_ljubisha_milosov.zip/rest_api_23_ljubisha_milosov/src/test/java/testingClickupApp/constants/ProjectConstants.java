package testingClickupApp.constants;

public class ProjectConstants {
    public static final String AUTHORIZATION = "pk_56590421_COAJKZKHWSMDLHWR7IE9ESU4UTJ26HUY";
    public static final String TEST_SPACE_ID = "90150270536";
    public static final String TEST_SPACE_NAME = "TestSpace";
}
